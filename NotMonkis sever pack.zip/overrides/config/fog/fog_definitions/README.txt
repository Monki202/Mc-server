This folder contains the unpacked fog definitions.
You can edit these files to customize the fog in your game.
For more information, visit https://docs.imb11.dev/fog/